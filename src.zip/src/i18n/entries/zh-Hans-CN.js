import zhMessages from '../locales/zh-Hans.json';

const ZhLan = {
  messages: {
    ...zhMessages,
  },
  locale: 'zh-Hans-CN',
};
export default ZhLan;
